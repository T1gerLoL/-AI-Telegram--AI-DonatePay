import subprocess
import threading
import logging
import json
import requests
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types, executor
from config import BOT_TOKEN, DEEPINFRA_API_KEY, DONATEPAY_LINK
from collections import defaultdict
import os

logging.basicConfig(level=logging.INFO)

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)

ADMIN_ID = 6108610810
SUB_FILE = "subscriptions.json"
USER_FILE = "users.json"
LOG_FILE = "logs.txt"

user_requests = defaultdict(int)
user_styles = {}
MAX_FREE_REQUESTS = 10

if os.path.exists(SUB_FILE):
    with open(SUB_FILE, "r") as f:
        subscriptions = json.load(f)
else:
    subscriptions = {}

if os.path.exists(USER_FILE):
    with open(USER_FILE, "r") as f:
        known_users = json.load(f)
else:
    known_users = {}

def save_subscriptions():
    with open(SUB_FILE, "w") as f:
        json.dump(subscriptions, f)

def save_users():
    with open(USER_FILE, "w") as f:
        json.dump(known_users, f)

def log_message(uid, text):
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{datetime.now()}] {uid}: {text}\n")

def has_active_sub(user_id: int):
    if str(user_id) in subscriptions:
        end_date = datetime.strptime(subscriptions[str(user_id)], "%Y-%m-%d")
        return end_date >= datetime.now()
    return False

def get_main_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("🚀 Начать", "📦 Купить подписку", "✅ Проверка подписки")
    return kb

def get_style_menu():
    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("🎓 Обычный", "😄 Шуточный", "📘 Формальный", "🔙 Назад")
    return kb

@dp.message_handler(commands=["start"])
async def start_cmd(message: types.Message):
    uid = str(message.from_user.id)
    if uid not in known_users:
        known_users[uid] = {
            "name": message.from_user.first_name,
            "username": message.from_user.username,
            "joined": str(datetime.now())
        }
        save_users()
    await message.answer(
        "👋 Привет, {0}! "
        "Я — Умник AI 🤖, помогу с идеями, текстами и ответами. "
        "❗ Запрещено использовать меня для: "
        "- Тематики 18+ "
        "- Терроризма " 
        "- Пропаганды насилия и прочего нелегального контента ".format(message.from_user.first_name),
        reply_markup=get_main_menu())

@dp.message_handler(lambda m: m.text == "🔙 Назад")
async def back(message: types.Message):
    await message.answer("↩️ Вернулся в главное меню", reply_markup=get_main_menu())

@dp.message_handler(lambda m: m.text == "📦 Купить подписку")
async def buy(message: types.Message):
    kb = types.InlineKeyboardMarkup()
    kb.add(types.InlineKeyboardButton("💳 Перейти к оплате", url=DONATEPAY_LINK))
    await message.answer(
        "💳 Чтобы оплатить подписку: "
        "1. Нажми на кнопку ниже и перейди на сайт оплаты. "
        "2. Укажи сумму (150 / 450 / 600 ₽). "
        "3. В комментарии к оплате укажи свой Telegram ID и количество дней через пробел. "
        "📌 Пример: `123456789 1` "
        "❗ НЕ указывай @username — используй только ID (цифры)."
        "Узнать свой ID можно через @userinfobot. "
        "Подписка активируется автоматически в течение 1 минуты после оплаты.",
        reply_markup=kb,
        parse_mode="Markdown"
    )

@dp.message_handler(lambda m: m.text == "✅ Проверка подписки")
async def check(message: types.Message):
    uid = str(message.from_user.id)
    if uid in subscriptions:
        await message.answer(f"✅ Подписка активна до: {subscriptions[uid]}")
    else:
        await message.answer("❌ У тебя нет активной подписки.")

@dp.message_handler(commands=["sub"])
async def give_subscription(message: types.Message):
    if message.from_user.id != ADMIN_ID:
        return await message.reply("⛔ Только админ может выдавать подписки.")
    parts = message.text.split()
    if len(parts) != 3:
        return await message.reply("❗ Формат: /sub user_id дней (например: /sub 123456789 7)")
    uid, days = parts[1], int(parts[2])
    end_date = datetime.now() + timedelta(days=days)
    subscriptions[uid] = end_date.strftime("%Y-%m-%d")
    save_subscriptions()
    await message.reply(f"✅ Подписка выдана пользователю {uid} до {subscriptions[uid]}")

@dp.message_handler(lambda m: m.text == "🚀 Начать")
async def start_chat(message: types.Message):
    uid = str(message.from_user.id)
    if not has_active_sub(uid) and user_requests[uid] >= MAX_FREE_REQUESTS:
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("💳 Оплатить (DonatePay)", url=DONATEPAY_LINK))
        await message.answer("🚫 Лимит бесплатных запросов исчерпан.", reply_markup=kb)
        return
    user_requests[uid] += 1
    await message.answer("🧠 Выбери стиль ответа:", reply_markup=get_style_menu())

@dp.message_handler(lambda m: m.text in ["🎓 Обычный", "😄 Шуточный", "📘 Формальный"])
async def set_style(message: types.Message):
    uid = str(message.from_user.id)
    style = message.text
    user_styles[uid] = style
    await message.answer("✍️ Напиши вопрос — я отвечу в стиле: " + style, reply_markup=types.ReplyKeyboardMarkup(resize_keyboard=True).add("🔙 Назад"))

@dp.message_handler()
async def handle_message(message: types.Message):
    if message.text == "🔙 Назад":
        await back(message)
        return
    uid = str(message.from_user.id)
    if not has_active_sub(uid) and user_requests[uid] >= MAX_FREE_REQUESTS:
        kb = types.InlineKeyboardMarkup()
        kb.add(types.InlineKeyboardButton("💳 Оплатить (DonatePay)", url=DONATEPAY_LINK))
        await message.answer("🚫 Лимит бесплатных запросов исчерпан.", reply_markup=kb)
        return
    user_requests[uid] += 1
    log_message(uid, message.text)
    prefix = ""
    style = user_styles.get(uid, "🎓 Обычный")
    if style == "😄 Шуточный":
        prefix = "Ответь с юмором и мемами: "
    elif style == "📘 Формальный":
        prefix = "Ответь строго и официально: "
    try:
        url = "https://api.deepinfra.com/v1/openai/chat/completions"
        headers = {
            "Authorization": f"Bearer {DEEPINFRA_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": "mistralai/Mixtral-8x7B-Instruct-v0.1",
            "messages": [{"role": "user", "content": prefix + message.text}],
            "temperature": 0.7
        }
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        reply = response.json()["choices"][0]["message"]["content"]
        await message.answer(reply, reply_markup=types.ReplyKeyboardMarkup(resize_keyboard=True).add("🔙 Назад"))
    except Exception as e:
        logging.error(f"DeepInfra error: {e}")
        await message.answer("⚠️ Ошибка при обращении к AI. Попробуй позже.", reply_markup=types.ReplyKeyboardMarkup(resize_keyboard=True).add("🔙 Назад"))

def start_checker():
    def run():
        subprocess.Popen(["python", "donate_checker.py"])
    threading.Thread(target=run, daemon=True).start()

start_checker()

if __name__ == "__main__":
    from keep_alive import keep_alive
    keep_alive()
    executor.start_polling(dp, skip_updates=True)