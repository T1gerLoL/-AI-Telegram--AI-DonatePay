# 🤖 Умник AI — Telegram-бот на Python + AI

Этот бот умеет:
- Отвечать на вопросы с помощью AI (DeepInfra / Mistral 8x7B)
- Поддерживает стили ответов: обычный, шуточный, формальный
- Имеет лимит бесплатных сообщений и платные подписки через DonatePay
- Сохраняет пользователей и логирует вопросы

## 🔧 Используемые технологии
- Python 3.10+
- aiogram
- requests
- threading
- JSON для хранения данных
- DeepInfra API
- DonatePay API

## 🚀 Запуск
1. Установи зависимости:
```bash
pip install -r requirements.txt
```

2. Создай файл `config.py` на основе `config_template.py`:
```python
BOT_TOKEN = "твой_бот_токен"
DEEPINFRA_API_KEY = "твой_API_ключ"
DONATEPAY_LINK = "https://new.donatepay.ru/@твойник"
```

3. Запусти бота:
```bash
python main.py
```

## 📌 DonatePay инструкция
Пользователь оплачивает подписку и в комментарии указывает:
```
<Telegram ID> <дни>
```
Пример:
```
6108610810 3
```

## 🛡️ Правила
Боту запрещено задавать вопросы на темы:
- 18+
- насилия
- терроризма
- нарушений закона
