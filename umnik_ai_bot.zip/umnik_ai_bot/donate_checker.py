import requests
import json
import os
import asyncio
from datetime import datetime, timedelta
from aiogram import Bot

# 🔐 Настройки
API_KEY = "0fJXNhYBP6UGR4DEpNAM4O9xUZxmpZsdYLDI4KxdVCnLK2ZBO2FV8Hlt1Kf2"
BOT_TOKEN = "8185020910:AAEKIkve5F5O2BjWf0xxpziUDHfPBcG_PB8"
ADMIN_ID = 6108610810

SUB_FILE = "subscriptions.json"
USER_FILE = "users.json"

bot = Bot(token=BOT_TOKEN)


async def give_sub_by_username(username, days):
    if not os.path.exists(USER_FILE) or not os.path.exists(SUB_FILE):
        with open("donate_errors.txt", "a", encoding="utf-8") as log:
            log.write(
                f"[{datetime.now()}] ❌ Нет файла users.json или subscriptions.json\n"
            )
        return

    with open(USER_FILE, "r") as f:
        users = json.load(f)
    with open(SUB_FILE, "r") as f:
        subscriptions = json.load(f)

    for uid, info in users.items():
        if info.get("username",
                    "").lower() == username.lower().replace("@", ""):
            end_date = datetime.now() + timedelta(days=int(days))
            subscriptions[uid] = end_date.strftime("%Y-%m-%d")
            with open(SUB_FILE, "w") as f:
                json.dump(subscriptions, f)
            with open("donate_log.txt", "a", encoding="utf-8") as log:
                log.write(
                    f"[{datetime.now()}] Выдано @{username} на {days} дней\n")
            await bot.send_message(
                ADMIN_ID, f"✅ Выдано @{username} подписка на {days} дней.")
            return True

    with open("donate_errors.txt", "a", encoding="utf-8") as log:
        log.write(
            f"[{datetime.now()}] ❌ Пользователь @{username} не найден.\n")
    return False


async def check_donates():
    url = "https://new.donatepay.ru/api/v1/donates"
    headers = {"Authorization": f"Bearer {API_KEY}"}
    try:
        response = requests.get(url, headers=headers)

        if not response.text.strip():
            with open("donate_errors.txt", "a", encoding="utf-8") as log:
                log.write(f"[{datetime.now()}] ❌ Пустой ответ от DonatePay\n")
            return

        try:
            data = response.json()
        except json.JSONDecodeError:
            with open("donate_errors.txt", "a", encoding="utf-8") as log:
                log.write(
                    f"[{datetime.now()}] ❌ Ошибка JSON. Ответ: {response.text}\n"
                )
            return

        if not data.get("data"):
            return

        for donation in data["data"]:
            comment = donation["message"]
            parts = comment.split()
            if len(parts) >= 2:
                username = parts[0]
                try:
                    days = int(parts[1])
                    await give_sub_by_username(username, days)
                except ValueError:
                    continue
    except Exception as e:
        with open("donate_errors.txt", "a", encoding="utf-8") as log:
            log.write(
                f"[{datetime.now()}] ❌ Запрос завершился с ошибкой: {e}\n")


async def main():
    while True:
        await check_donates()
        await asyncio.sleep(60)


if __name__ == "__main__":
    asyncio.run(main())
