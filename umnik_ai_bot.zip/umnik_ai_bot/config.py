# Telegram
BOT_TOKEN = "8185020910:AAEKIkve5F5O2BjWf0xxpziUDHfPBcG_PB8"

# DonatePay
DONATEPAY_LINK = "https://new.donatepay.ru/@umnikai"

# DeepInfra API
DEEPINFRA_API_KEY = "e4lA5Fnqi0TEdYm0voFFHR2bjh6ZruMz"  # ✅ правильно

